package com.huaxin.wangshen.sak.RunViews;

import com.bin.david.form.data.column.ColumnInfo;

public interface LongColumnClickListener {
    void longClick(ColumnInfo columnInfo);
}
