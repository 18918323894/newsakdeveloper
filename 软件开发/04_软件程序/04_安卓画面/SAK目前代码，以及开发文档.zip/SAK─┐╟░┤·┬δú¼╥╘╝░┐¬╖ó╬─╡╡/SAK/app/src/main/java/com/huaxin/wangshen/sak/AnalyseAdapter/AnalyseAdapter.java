package com.huaxin.wangshen.sak.AnalyseAdapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

import com.lijianxun.multilevellist.adapter.MultiLevelAdapter;

public class AnalyseAdapter extends MultiLevelAdapter {
    public AnalyseAdapter(Context context, boolean isExpandable, boolean isExpandAll, int expandLevel) {
        super(context, isExpandable, isExpandAll, expandLevel);
    }

    @Override
    public View onCreateView(int i, View view, ViewGroup viewGroup) {
        return null;
    }
}
