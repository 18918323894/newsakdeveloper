package com.huaxin.wangshen.sak.RunModel;

public class WaitBeen {
    public WaitBeen(int no,String name,int time,String tiaojian,String zhuangtai,int suoding){
        this.no = no;
        this.name = name;
        this.time = time;
        this.tiaojian = tiaojian;
        this.zhuangtai = zhuangtai;
        this.suoding = suoding;
    }
    private int no;
    private String name;
    private int time;
    private String tiaojian;
    private String zhuangtai;
    private int suoding;

}
