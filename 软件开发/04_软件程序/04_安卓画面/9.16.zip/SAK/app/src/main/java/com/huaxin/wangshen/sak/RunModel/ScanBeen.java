package com.huaxin.wangshen.sak.RunModel;

public class ScanBeen {
    public ScanBeen(int scan,String name,String bendi){
        this.scan = scan;
        this.name = name;
        this.bendi = bendi;
    }
    private int scan;
    private String name;
    private String bendi;

}
