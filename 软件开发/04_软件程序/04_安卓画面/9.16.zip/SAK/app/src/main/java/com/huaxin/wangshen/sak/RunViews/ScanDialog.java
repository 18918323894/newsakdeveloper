package com.huaxin.wangshen.sak.RunViews;

import android.app.Dialog;
import android.content.Context;
//import android.content.DialogInterface;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.huaxin.wangshen.sak.R;


public class ScanDialog extends Dialog {

//    public TextView scan_text = findViewById(R.id.scan_text);
//    private ImageView close = findViewById(R.id.scan_close);
//    private EditText scan_edit = findViewById(R.id.scan_edit);
public TextView scan_text ;
    private ImageView close ;
    private EditText scan_edit ;
    public interface ScanEnter{
        public void call_back();
    }
    private ScanEnter scanEnter;
    public ScanDialog( Context context,ScanEnter enter) {
        this(context,0);
        this.scanEnter = enter;
    }

    public ScanDialog( Context context, int themeResId) {
        this(context, true,null);
    }

    protected ScanDialog( Context context, boolean cancelable, OnCancelListener cancelListener) {
        super(context, cancelable, cancelListener);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scan_dialog);
        scan_text = findViewById(R.id.scan_text);
        scan_edit = findViewById(R.id.scan_edit);
        close = findViewById(R.id.scan_close);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        scan_edit.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEND || actionId == EditorInfo.IME_ACTION_DONE || (event != null && KeyEvent.KEYCODE_ENTER == event.getKeyCode() && KeyEvent.ACTION_DOWN == event.getAction()))
                {
                    scanEnter.call_back();
                    return true;
                }else{
                    return false;
                }
            }
        });

    }
}
