package com.huaxin.wangshen.sak.AnalyseAdapter;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.support.constraint.ConstraintLayout;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.huaxin.wangshen.sak.MainActivity;
import com.lijianxun.multilevellist.adapter.MultiLevelAdapter;
import com.lijianxun.multilevellist.model.MultiLevelModel;
import com.huaxin.wangshen.sak.R;
import com.huaxin.wangshen.sak.AnalyseModel.*;
import com.qy.common.DateUtil;
import com.qy.common.ToastUtil;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static android.R.layout.simple_expandable_list_item_1;
import static android.R.layout.simple_spinner_item;

/**
 * Created by windows on 2017/12/29.
 */

public class MultiLevelTestAdapter extends MultiLevelAdapter {


    public MultiLevelTestAdapter(Context context, boolean isExpandable, boolean isExpandAll
            , int expandLevel) {
        super(context, isExpandable, isExpandAll, expandLevel);
    }

    @Override
    public View onCreateView(final int position, View convertView, ViewGroup parent) {
//                int ttt = getItemViewType(getViewTypeCount());

        Holder v = null;
        final MultiLevelModel model = (MultiLevelModel) getItem(position);

        if (model.getLevel()==0){
            convertView = mInflater.inflate(R.layout.first_item, null);
            v = new Holder(convertView);
            convertView.setTag(v);
            ImageView imageView = convertView.findViewById(R.id.item_jiantou);
            ConstraintLayout bc = convertView.findViewById(R.id.first_bc);
            if (model.isExpand() == false){
                imageView.setImageResource(R.mipmap.item_right);
                bc.setBackgroundResource(R.drawable.item_bc);
            }else {
                imageView.setImageResource(R.mipmap.item_bottom);
                bc.setBackgroundResource(R.drawable.item_bczhan);
            }
            ImageView close = convertView.findViewById(R.id.first_close);
            close.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    delete_parent_item(position);
                }
            });

        }
        if (model.getLevel()==1){
            convertView = mInflater.inflate(R.layout.second_item, null);
            v = new Holder(convertView);
            convertView.setTag(v);
            ImageView second_close = convertView.findViewById(R.id.second_close);
            second_close.setVisibility(View.GONE);
            TextView second_item_title = convertView.findViewById(R.id.second_item_title);
            ClassB b = (ClassB)model;
            second_item_title.setText(b.getLabel());
            ImageView imageView = convertView.findViewById(R.id.item_jiantou_2);
            ConstraintLayout bc = convertView.findViewById(R.id.second_bc);
            if (model.isExpand() == false){
                imageView.setImageResource(R.mipmap.item_right);
                bc.setBackgroundResource(R.drawable.item_child_bc);
            }else {
                imageView.setImageResource(R.mipmap.item_bottom);
                bc.setBackgroundResource(R.drawable.item_child_bczhan);
            }
            if (getBelongSecondIndex(position) == 1){
                ClassC c = b.getChildren().get(0);
                c.setExpand(true);
            }

        }
        if (model.getLevel()==2){
            if (getBelongSecondIndex(position) == 0){
                convertView = mInflater.inflate(R.layout.tongyong_item, null);

                String[] ctype = new String[]{"全部", "游戏", "电影", "娱乐", "图书"};
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(mContext,simple_spinner_item, ctype);  //创建一个数组适配器
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                Spinner sp  = convertView.findViewById(R.id.pickdate);
                sp.setAdapter(adapter);

                final TextView textView72 = convertView.findViewById(R.id.textView72);
                final TextView textView76 = convertView.findViewById(R.id.textView76);

                Date nowTime = new Date(System.currentTimeMillis());
                String nowDate = format.format(nowTime);
                textView72.setText(nowDate);
                textView76.setText(nowDate);
                sTime = nowDate;
                eTime = nowDate;

                textView72.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showPickData(0,textView72);
                    }
                });

                textView76.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showPickData(1,textView76);
                    }
                });
                v = new Holder(convertView);
                convertView.setTag(v);
            }
            if (getBelongSecondIndex(position) == 1){







                convertView = mInflater.inflate(R.layout.add_item, null);
                v = new Holder(convertView);
                convertView.setTag(v);
                final ImageView addchild = convertView.findViewById(R.id.add_tiaojian);
                addchild.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        popupWindow(addchild);
//                        ClassC c = (ClassC)model;
//                        c.getChildren().add(c.getChildren().get(0));
//                        notifyDataSetChanged();
                    }
                });
            }if (getBelongSecondIndex(position) == 2){
                convertView = mInflater.inflate(R.layout.item_message_text, null);
                v = new Holder(convertView);
                convertView.setTag(v);
            }if (getBelongSecondIndex(position) == 3){
                convertView = mInflater.inflate(R.layout.tongyong_item, null);
                v = new Holder(convertView);
                convertView.setTag(v);
            }
        }
        if (model.getLevel()==3){
            if (getBelongSecondIndex(position) == 1){
                convertView = mInflater.inflate(R.layout.second_item, null);
                v = new Holder(convertView);
                convertView.setTag(v);
                TextView t = convertView.findViewById(R.id.second_item_title);
                ClassD d = (ClassD) model;
                t.setText(d.getName());
                ImageView imageView = convertView.findViewById(R.id.item_jiantou_2);
                ConstraintLayout bc = convertView.findViewById(R.id.second_bc);
                if (model.isExpand() == false){
                    imageView.setImageResource(R.mipmap.item_right);
                    bc.setBackgroundResource(R.drawable.item_child_bc);
                }else {
                    imageView.setImageResource(R.mipmap.item_bottom);
                    bc.setBackgroundResource(R.drawable.item_child_bczhan);
                }
                ImageView close = convertView.findViewById(R.id.second_close);
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        delete_child_item(position);
                    }
                });
            }else {
                convertView = mInflater.inflate(R.layout.third_item, null);
                v = new Holder(convertView);
                convertView.setTag(v);
            }

        }
        if (model.getLevel() == 4){
            convertView = mInflater.inflate(R.layout.tongyong_item, null);
            v = new Holder(convertView);
            convertView.setTag(v);
        }
        switch (model.getLevel()) {
            case 0:
                ClassA a = (ClassA) model;
                v.tv.setText( a.getName());
//                TextView  tv = (TextView) convertView.findViewById(R.id.first_item_title);
//                tv.setText(a.getName());
                convertView.setPadding(0 , 0, 0, 10);
                break;
            case 1:
//                ClassB b = (ClassB) model;
//                v.tv.setText( b.getLabel());
                convertView.setPadding(0 , 0, 0, 10);
                break;
            case 2:
//                ClassC c = (ClassC) model;
//                v.tv.setText(c.getName());
//                TextView  tv1 = (TextView) convertView.findViewById(R.id.second_item_title);
//                tv1.setText(c.getName());
                convertView.setPadding(5 , 0, 5, 5);
                break;
            case 3:
//                ClassD d = (ClassD) model;
//                v.tv.setText( d.getName());
                convertView.setPadding(5 , 0, 5, 10);
                break;
        }

        return convertView;
    }


    private void delete_parent_item(int p){
        mList.remove(getMainIndex(p));
        notifyDataSetChanged();
    }

    private int getMainIndex(int p){
        int index = 0;
        int num = 0;
        for (int i = 0;i < mList.size();i++){
            num ++;
            ClassA a = (ClassA) mList.get(i);
            if (a.isExpand() == true){
                for (int j = 0;j< a.getChildren().size();j++){
                    num ++;
                    ClassB b = a.getChildren().get(j);
                    if (b.isExpand() == true){
                        for (int k = 0;k < b.getChildren().size();k++){
                            num ++;
                            ClassC c = b.getChildren().get(k);
                            if (c.isExpand() == true){
                                for (int l = 0;l < c.getChildren().size();l++){
                                    num ++;
                                    ClassD d = c.getChildren().get(l);
                                    if (d.isExpand() == true){
                                        num ++;
                                        if ((num - 1)>=p){
                                            index = i;
                                            return index;
                                        }
                                    }
                                    if ((num - 1)>=p){
                                        index = i;
                                        return index;
                                    }
                                }
                            }
                            if ((num - 1)>=p){
                                index = i;
                                return index;
                            }
                        }
                    }
                    if ((num - 1)>=p){
                        index = i;
                        return index;
                    }
                }
            }
        }
        return index;
    }


    private int getBelongSecondIndex(int p){
        int index = 0;
        int num = 0;
        for (int i = 0;i < mList.size();i++){
            num ++;
            ClassA a = (ClassA) mList.get(i);
            if (a.isExpand() == true){
                for (int j = 0;j< a.getChildren().size();j++){
                    num ++;
                    ClassB b = a.getChildren().get(j);
                    if (b.isExpand() == true){
                        for (int k = 0;k < b.getChildren().size();k++){
                            num ++;
                            ClassC c = b.getChildren().get(k);
                            if (c.isExpand() == true){
                                for (int l = 0;l < c.getChildren().size();l++){
                                    num ++;
                                    ClassD d = c.getChildren().get(l);
                                    if (d.isExpand() == true){
                                        num ++;
                                        if ((num - 1)>=p){
                                            index = j;
                                            return index;
                                        }
                                    }
                                    if ((num - 1)>=p){
                                        index = j;
                                        return index;
                                    }
                                }
                            }
                            if ((num - 1)>=p){
                                index = j;
                                return index;
                            }
                        }
                    }
                    if ((num - 1)>=p){
                        index = j;
                        return index;
                    }
                }
            }
        }
        return index;
    }
    private void delete_child_item(int p){
        int index = 0;
        int num = 0;
        for (int i = 0;i < mList.size();i++){
            num ++;
            ClassA a = (ClassA) mList.get(i);
            if (a.isExpand() == true){
                for (int j = 0;j< a.getChildren().size();j++){
                    num ++;
                    ClassB b = a.getChildren().get(j);
                    if (b.isExpand() == true){
                        for (int k = 0;k < b.getChildren().size();k++){
                            num ++;
                            ClassC c = b.getChildren().get(k);
                            if (c.isExpand() == true){
                                num = num + c.getChildren().size();
                                for (int l = 0;l < c.getChildren().size();l++){
                                    ClassD d = c.getChildren().get(l);
                                    if (d.isExpand() == true){
                                        num ++;
                                        if ((num - 1)>=p){
                                            index = c.getChildren().size() - (num - 1 -p) -1;
                                            c.getChildren().remove(index);
                                            notifyDataSetChanged();
                                            return ;
                                        }
                                    }else {
                                        if ((num - 1)>=p){
                                            index = c.getChildren().size() - (num - 1 -p) -1;
                                            c.getChildren().remove(index);
                                            notifyDataSetChanged();
                                            return ;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    class Holder {
        TextView tv;
        public Holder(View view) {
            tv = (TextView) view.findViewById(R.id.first_item_title);
        }
    }

    android.app.DatePickerDialog start, end;
    Calendar calendar;
    int eyear, emonth, eday;
    int syear, smonth, sday;
    String sTime = "";
    String eTime = "";
    private SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

    private void showPickData(int type, final TextView tv){
        if (start == null) {
            // 获取日历对象
            calendar = Calendar.getInstance();
            // 获取当前对应的年、月、日的信息
            start = new android.app.DatePickerDialog(mContext, new android.app
                    .DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                    syear = year;
                    smonth = monthOfYear + 1;
                    sday = dayOfMonth;
                    sTime = syear + "-" + ((smonth > 9) ? smonth : ("0" + smonth)) + "-" + sday;
                    if ((date2TimeStamp(eTime) - date2TimeStamp(sTime)) >= 0) {
                        tv.setText(syear + "-" + ((smonth > 9) ? smonth : ("0" +
                                smonth)) + "-" + ((sday > 9) ? sday : ("0" + sday)));
                        start.cancel();
                    } else {
                        ToastUtil.showToast(mContext, "选择的结束日期小于开始日期");
                    }
                }
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar
                    .DAY_OF_MONTH));
        }
        if (end == null) {
            // 获取日历对象
            calendar = Calendar.getInstance();
            // 获取当前对应的年、月、日的信息
            end = new android.app.DatePickerDialog(mContext, new android.app
                    .DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                    eyear = year;
                    emonth = monthOfYear + 1;
                    eday = dayOfMonth;
                    eTime = eyear + "-" + ((emonth > 9) ? emonth : ("0" + emonth)) + "-" + eday;
                    if ((date2TimeStamp(eTime) - date2TimeStamp(sTime)) >= 0) {
                        tv.setText(eyear + "-" + ((emonth > 9) ? emonth : ("0" + emonth)
                        ) + "-" + ((eday > 9) ? eday : ("0" + eday)));
                        end.cancel();
                    } else {
                        ToastUtil.showToast(mContext, "选择的结束日期小于开始日期");
                    }

                }
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar
                    .DAY_OF_MONTH));
        }

        switch (type) {
            case 0:
                start.show();
                break;
            case 1:
                end.show();
                break;
        }
    }
    public static Long date2TimeStamp(String str) {
        Long time = null;
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            Date date = format.parse(str);
            time = date.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return time;
    }
    private PopupWindow popup;
    private ArrayList<String> datas;
    /**
     * 显示窗口
     */
    private void popupWindow(ImageView imageView){
        ListView listView = new ListView(mContext);
        datas = new ArrayList<>();
        datas.add("Filter");
        datas.add("Split");
        datas.add("Aggregate");
        datas.add("Sort");

        listView.setDivider(null);//设置分割线
        listView.setVerticalScrollBarEnabled(false);//不显示滑动条
        listView.setAdapter(new MyAdapter());

        popup = new PopupWindow(mContext);
        popup.setWidth(imageView.getWidth());
        popup.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
        popup.setContentView(listView);//设置显示内容
        popup.setOutsideTouchable(true);//点击PopupWindow以外的区域自动关闭该窗口
        popup.showAsDropDown(imageView, 0, 0);//显示在edit控件的下面0,0代表偏移量
    }

    //适配器
    private class MyAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return datas.size();
        }

        @Override
        public Object getItem(int position) {
            return position;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            HolderView holderView=null;
            if(convertView==null){
                convertView=View.inflate(mContext, R.layout.pop_menuitem,null);
                holderView=new HolderView();
                holderView.text= convertView.findViewById(R.id.textView);
                convertView.setTag(holderView);
            }else{
                holderView=(HolderView) convertView.getTag();
            }
            holderView.text.setText(datas.get(position));
            //listview的单击事件
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //将单机的这项的文本显示在EditText中，并关闭窗口
                    popup.dismiss();//关闭窗口
                }
            });
            return convertView;
        }
        class HolderView{//由于这里用户都是同一个人,就省略用户图像的刷新
            private TextView text;
        }
    }

}
