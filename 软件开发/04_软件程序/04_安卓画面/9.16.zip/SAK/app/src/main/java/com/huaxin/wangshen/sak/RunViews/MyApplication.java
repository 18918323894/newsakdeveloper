package com.huaxin.wangshen.sak.RunViews;

import android.app.Application;
import android.view.WindowManager;

public class MyApplication extends Application {
    /**
     * 创建全局变量
     * 注意在AndroidManifest.xml中的Application节点添加android:name=".MyApplication"属性
     *
     */
    private WindowManager.LayoutParams wmParams=new WindowManager.LayoutParams();

    public WindowManager.LayoutParams getMywmParams(){
        return wmParams;
    }
}
